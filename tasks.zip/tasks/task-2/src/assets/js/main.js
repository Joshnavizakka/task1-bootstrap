// Custom JavaScript for Task 2 - Nunjucks + Gulp Project

// Form submission handler
document.addEventListener('DOMContentLoaded', function() {
  const contactForm = document.querySelector('form');
  
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      alert('Thank you for your message! We will get back to you soon.');
      contactForm.reset();
    });
  }
  
  console.log('Task 2 - Nunjucks + Gulp Project loaded successfully!');
});
