# 📌 Task 2 - Bootstrap UI with Nunjucks & Gulp

## 🎯 Objective

Recreate the deliverables from Task 1 (Bootstrap UI Project) using a **templating engine** and **bundler/task runner** combination as per the mandatory technology stack requirements.

---

## 🛠️ Technology Stack

### Templating Engine: **Nunjucks**
- Nunjucks is a powerful templating engine by Mozilla
- Features include template inheritance, macros, loops, and conditionals
- Chosen for its flexibility and similarity to Jinja2/Django templates

### Task Runner: **Gulp**
- Gulp is a streaming build system for automating development tasks
- Used for compiling templates, copying assets, and live reloading
- Chosen for its simplicity and extensive plugin ecosystem

---

## 📂 Folder Structure

```
task-2/
├── src/
│   ├── templates/
│   │   ├── layouts/
│   │   │   └── base.njk          # Base layout template
│   │   ├── partials/
│   │   │   ├── navbar.njk        # Reusable navbar component
│   │   │   └── footer.njk        # Reusable footer component
│   │   └── pages/
│   │       ├── index.njk         # Home page template
│   │       ├── about.njk         # About page template
│   │       └── contact.njk       # Contact page template
│   └── assets/
│       ├── css/
│       │   └── style.css         # Custom styles
│       └── js/
│           └── main.js           # Custom JavaScript
├── dist/                         # Compiled output (generated)
├── package.json                  # Project dependencies
├── gulpfile.js                   # Gulp task configuration
└── README.md                     # This file
```

---

## 🚀 Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- npm (comes with Node.js)

### Steps

1. **Navigate to the project directory:**
   ```bash
   cd task-2
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Build the project:**
   ```bash
   npm run build
   ```

4. **Start development server with live reload:**
   ```bash
   npm run dev
   ```
   or
   ```bash
   npm start
   ```

---

## 📜 Available Commands

| Command | Description |
|---------|-------------|
| `npm run build` | Compiles templates and copies assets to `dist/` |
| `npm run dev` | Starts dev server with live reload |
| `npm start` | Same as `npm run dev` |

---

## ✨ Features Implemented

### Template Features
- ✅ **Template Inheritance** - Base layout with extendable blocks
- ✅ **Partials** - Reusable navbar and footer components
- ✅ **Loops** - Dynamic rendering of cards, slides, and form fields
- ✅ **Variables** - Site name and year passed from Gulp
- ✅ **Conditionals** - Active class toggling in carousel

### Pages
- ✅ **Home (index.html)** - Hero carousel + Features section
- ✅ **About (about.html)** - About section + Technologies + Modal
- ✅ **Contact (contact.html)** - Contact info + Form

### Bootstrap Components Used
- Navbar (responsive)
- Carousel (hero slider)
- Cards (features, technologies)
- Modal (learn more popup)
- Forms (contact form)
- Grid System (responsive layouts)

---

## 🔗 Related Links

- [Nunjucks Documentation](https://mozilla.github.io/nunjucks/)
- [Gulp Documentation](https://gulpjs.com/docs/en/getting-started/quick-start)
- [Bootstrap 5 Documentation](https://getbootstrap.com/docs/5.3/)
- [Jamstack Architecture](https://jamstack.org/)

---

## 📸 Screenshots

*(Add screenshots of the compiled output here)*

---

## ⏱️ Time Taken

Approximately 4-5 hours

---

## 👤 Author

Saket

---

## 📄 License

MIT License
