const gulp = require('gulp');
const nunjucksRender = require('gulp-nunjucks-render');
const browserSync = require('browser-sync').create();
const htmlmin = require('gulp-htmlmin');
const { rimraf } = require('rimraf');

// Paths configuration
const paths = {
  templates: {
    src: 'src/templates/pages/**/*.njk',
    partials: 'src/templates/',
    dest: 'dist/'
  },
  assets: {
    css: 'src/assets/css/**/*.css',
    js: 'src/assets/js/**/*.js',
    images: 'src/assets/images/**/*',
    dest: 'dist/assets/'
  }
};

// Compile Nunjucks templates to HTML
function nunjucks() {
  return gulp.src(paths.templates.src)
    .pipe(nunjucksRender({
      path: [paths.templates.partials],
      data: {
        siteName: 'MyProject',
        year: new Date().getFullYear()
      }
    }))
    .pipe(htmlmin({ 
      collapseWhitespace: false,
      removeComments: false 
    }))
    .pipe(gulp.dest(paths.templates.dest))
    .pipe(browserSync.stream());
}

// Copy CSS files
function css() {
  return gulp.src(paths.assets.css)
    .pipe(gulp.dest(paths.assets.dest + 'css/'))
    .pipe(browserSync.stream());
}

// Copy JS files
function js() {
  return gulp.src(paths.assets.js)
    .pipe(gulp.dest(paths.assets.dest + 'js/'))
    .pipe(browserSync.stream());
}

// Copy images
function images() {
  return gulp.src(paths.assets.images, { allowEmpty: true })
    .pipe(gulp.dest(paths.assets.dest + 'images/'));
}

// Clean dist folder
async function clean() {
  await rimraf('dist');
}

// Browser Sync server
function serve() {
  browserSync.init({
    server: {
      baseDir: './dist'
    },
    port: 3000,
    open: true
  });
}

// Watch for changes
function watchFiles() {
  gulp.watch('src/templates/**/*.njk', nunjucks);
  gulp.watch(paths.assets.css, css);
  gulp.watch(paths.assets.js, js);
  gulp.watch(paths.assets.images, images);
}

// Build task
const build = gulp.series(clean, gulp.parallel(nunjucks, css, js, images));

// Default task (development)
const dev = gulp.series(build, gulp.parallel(serve, watchFiles));

// Watch task
const watch = gulp.series(build, gulp.parallel(serve, watchFiles));

// Export tasks
exports.nunjucks = nunjucks;
exports.css = css;
exports.js = js;
exports.images = images;
exports.clean = clean;
exports.build = build;
exports.watch = watch;
exports.default = dev;
