# Bootstrap 5 UI Exploration Project

## Objective
The objective of this project is to explore Bootstrap 5 components and design clean, responsive web pages.

## Description
This project contains three pages: Home, About, and Contact. Bootstrap components such as Navbar, Cards, Forms, and Grid system are used to create a modern UI.

## Technologies Used
- HTML5
- CSS3
- Bootstrap 5
- Git & GitHub

## Tools Used
- Bootstrap official documentation
- ChatGPT (for guidance and understanding concepts)

## Challenges Faced
Understanding Bootstrap grid system and responsive layouts was a challenge initially, which was solved by practicing column classes.

## Time Taken
Approximately 5–6 hours.
